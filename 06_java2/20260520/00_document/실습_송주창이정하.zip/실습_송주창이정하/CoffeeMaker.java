package 실습.실습_송주창이정하;

public interface CoffeeMaker {
	
	 	Drink makeAmericano(char size);
	    Drink makeLatte(char size);
	    Drink makeAde(char size);

	    void printMenu();
}
