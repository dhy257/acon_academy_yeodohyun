package 실습.실습_송주창이정하;

import java.util.ArrayList;

public class TwosomeMachine implements CoffeeMaker{
    @Override
    public Drink makeAmericano(char size) {
        ArrayList<String> ingredient = new ArrayList<>();

        ingredient.add("에스프레소 샷");
        ingredient.add("물");
        ingredient.add("얼음");

        return new Drink ("투썸플레이스 아메리카노", 3500, size, ingredient );
    }

    @Override
    public Drink makeLatte(char size) {
        ArrayList<String> ingredient = new ArrayList<>();
        ingredient.add("초코 시럽");
        ingredient.add("우유");
        ingredient.add("얼음");
        ingredient.add("휘핑크림 토핑");

        return new Drink("투썸플레이스 초코라떼", 4200, size, ingredient );
    }

    @Override
    public Drink makeAde(char size) {

        ArrayList<String> ingredient = new ArrayList<>();
        ingredient.add("꿀");
        ingredient.add("레몬 베이스");
        ingredient.add("탄산수");
        ingredient.add("얼음");
        ingredient.add("민트 토핑");

        return new Drink("투썸플레이스 허니레몬에이드", 5200, size, ingredient);
    }

    @Override
    public void printMenu() {
        System.out.println("1. " + makeAmericano('T'));
        System.out.println("2. " + makeLatte('T'));
        System.out.println("3. " + makeAde('T'));
    }
}
