package 실습.실습_송주창이정하;
import java.util.ArrayList;

public class Drink {
    String name;
    int price;
    char size; //T(Tall), G(Grande), V(Venti)
    ArrayList<String> ingredient;

    public Drink(String name, int price, char size, ArrayList<String> ingredient) {
        this.name = name;
        this.price = price;
        this.size = size;
        this.ingredient = ingredient;
    }
   

    @Override
    public String toString() {
        return name + " - " + price + "원";
    }
}
