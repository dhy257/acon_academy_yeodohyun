package 실습.실습_송주창이정하;

import java.util.ArrayList;

public class MegaCoffeeMachine implements CoffeeMaker{

    @Override
    public Drink makeAmericano(char size) {
        ArrayList<String> ingredient = new ArrayList<>();

        ingredient.add("에스프레소 샷");
        ingredient.add("물");
        ingredient.add("얼음");

        return new Drink ("메가커피 아메리카노", 2000, size, ingredient );

    }

    @Override
    public Drink makeLatte(char size) {
        ArrayList<String> ingredient = new ArrayList<>();
        ingredient.add("에스프레소 샷");
        ingredient.add("우유");
        ingredient.add("얼음");

        return new Drink("메가커피 카페라떼", 3000, size, ingredient );
    }

    @Override
    public Drink makeAde(char size) {
        ArrayList<String> ingredient = new ArrayList<>();
        ingredient.add("레몬 베이스");
        ingredient.add("탄산수");
        ingredient.add("얼음");

        return new Drink("메가커피 레몬에이드", 4500, size, ingredient );
    }

    @Override
    public void printMenu() {
        System.out.println("1. " + makeAmericano('T'));
        System.out.println("2. " + makeLatte('T'));
        System.out.println("3. " + makeAde('T'));
    }
}
