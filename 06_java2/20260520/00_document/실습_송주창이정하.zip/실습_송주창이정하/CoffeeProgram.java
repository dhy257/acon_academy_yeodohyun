package 실습.실습_송주창이정하;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;
import java.util.Scanner;

public class CoffeeProgram {
	
	
	CoffeeMaker coffeeMaker;
	
	
	public void setCoffeeMaker(CoffeeMaker coffeeMaker) {
		this.coffeeMaker = coffeeMaker;
	}

	public void run() {
	    Scanner sc = new Scanner(System.in);

	    System.out.println("====커피 제작 프로그램====");
	    System.out.println("커피 제조를 시작합니다...");

		System.out.println();
	    System.out.println("===== 메뉴 선택 =====");
	    coffeeMaker.printMenu();

	    int menu = inputMenu(sc);

	    System.out.println();
	    System.out.println("===== 사이즈 선택 =====");
	    System.out.println("T. Tall");
	    System.out.println("G. Grande");
	    System.out.println("V. Venti");
	    char size = inputSize(sc);

	    Drink drink = null;

	    if (menu == 1) {
	        drink = coffeeMaker.makeAmericano(size);
	    } else if (menu == 2) {
	        drink = coffeeMaker.makeLatte(size);
	    } else if (menu == 3) {
	        drink = coffeeMaker.makeAde(size);
	    }

	    System.out.println();
	    System.out.println("===== 주문 결과 =====");
	    System.out.println("name: " + drink.name);
	    System.out.println("price: " + drink.price);
	    System.out.println("size: " + drink.size);
	    System.out.println("ingredient: " + drink.ingredient);

	    System.out.println("====커피 제작 완료====");

	    sc.close();
	}

	private int inputMenu(Scanner sc) {
		while (true) {
			System.out.print("메뉴 번호 입력: ");
			int menu = sc.nextInt();

			if (menu >= 1 && menu <= 3) {
				return menu;
			}

			System.out.println("잘못된 메뉴 번호입니다. 다시 입력해주세요.");
		}
	}

	private char inputSize(Scanner sc) {
		while (true) {
			System.out.print("사이즈 입력: ");
			char size = Character.toUpperCase(sc.next().charAt(0));

			if (size == 'T' || size == 'G' || size == 'V') {
				return size;
			}

			System.out.println("잘못된 사이즈입니다. T, G, V 중에서 다시 입력해주세요.");
		}
	}
	
	
	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException,
	    InstantiationException, IllegalAccessException, IllegalArgumentException,
	    InvocationTargetException, NoSuchMethodException, SecurityException {
	
		Properties p = new Properties();
		p.load(new FileReader("src/실습/테스트/config.txt"));
			
	
		String name = p.getProperty("coffee");
			
		Class clazz = Class.forName(name);
		CoffeeMaker machine = (CoffeeMaker) clazz.getDeclaredConstructor().newInstance();
		
		CoffeeProgram cp = new CoffeeProgram();
			cp.setCoffeeMaker(machine);
			cp.run();
}
}
