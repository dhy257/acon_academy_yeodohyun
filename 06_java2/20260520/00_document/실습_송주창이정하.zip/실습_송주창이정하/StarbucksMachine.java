package 실습.실습_송주창이정하;

import java.util.ArrayList;

public class StarbucksMachine implements CoffeeMaker{
    @Override
    public Drink makeAmericano(char size) {
        ArrayList<String> ingredient = new ArrayList<>();

        ingredient.add("에스프레소 샷");
        ingredient.add("물");
        ingredient.add("얼음");

        return new Drink ("스타벅스 아메리카노", 4000, size, ingredient );

    }

    @Override
    public Drink makeLatte(char size) {
        ArrayList<String> ingredient = new ArrayList<>();
        ingredient.add("에스프레소 샷");
        ingredient.add("연유");
        ingredient.add("우유");
        ingredient.add("얼음");

        return new Drink("스타벅스 돌체라떼", 4800, size, ingredient );
    }

    @Override
    public Drink makeAde(char size) {

        ArrayList<String> ingredient = new ArrayList<>();
        ingredient.add("딸기 베이스");
        ingredient.add("아사이베리 주스");
        ingredient.add("레몬 베이스");
        ingredient.add("탄산수");
        ingredient.add("얼음");

        return new Drink("스타벅스 딸기 아사이 레모네이드", 5000, size, ingredient );
    }

    @Override
    public void printMenu() {
        System.out.println("1. " + makeAmericano('T'));
        System.out.println("2. " + makeLatte('T'));
        System.out.println("3. " + makeAde('T'));
    }

}
