package day4prac.짝꿍실습;

public interface 금병영직원 {
	
	void 영상편집();
	
	void 유튜브출연();

}
