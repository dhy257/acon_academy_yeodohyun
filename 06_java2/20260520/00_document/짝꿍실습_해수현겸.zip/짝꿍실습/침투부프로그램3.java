package day4prac.짝꿍실습;

public class 침투부프로그램3 {
	
	금병영직원 emp;


	public void setEmp(금병영직원 emp) {
		this.emp = emp;
	}

	public void run() {
		System.out.println("직원 일을 시킬게요");
		emp.유튜브출연();
	}

	public static void main(String[] args) {

		침투부프로그램3 p1 = new 침투부프로그램3();
		침투부프로그램3 p2 = new 침투부프로그램3();
		
		p1.setEmp(new 통닭천사());
		p2.setEmp(new 김쥐똥고추());
		
		p1.run();
		p2.run();

	}

}
