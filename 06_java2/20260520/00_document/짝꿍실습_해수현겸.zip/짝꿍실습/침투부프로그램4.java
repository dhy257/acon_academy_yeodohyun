package day4prac.짝꿍실습;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;

public class 침투부프로그램4 {
	
	금병영직원 emp;


	public void setEmp(금병영직원 emp) {
		this.emp = emp;
	}

	public void run() {
		System.out.println("직원 일을 시킬게요");
		emp.유튜브출연();
	}

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {

		Properties p = new Properties();
		p.load(new FileReader("src/day4prac/짝꿍실습/config.txt"));
		String className = p.getProperty("emp");
		
		Class clazz = Class.forName(className);
		금병영직원 emp = (금병영직원)clazz.getDeclaredConstructor().newInstance();
		
		침투부프로그램4 pp = new 침투부프로그램4();
		pp.setEmp(emp);
		pp.run();
		

	}

}
