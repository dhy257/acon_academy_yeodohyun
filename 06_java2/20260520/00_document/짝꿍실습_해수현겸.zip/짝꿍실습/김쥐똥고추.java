package day4prac.짝꿍실습;

public class 김쥐똥고추 implements 금병영직원 {

	@Override
	public void 영상편집() {
		System.out.println("김쥐똥고추는 영상을 편집한다");
		
	}
	
	@Override
	public void 유튜브출연() {

		System.out.println("소개팅을 나가서 디진다돈까스를 먹는다");
		
	}
}
