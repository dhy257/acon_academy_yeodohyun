package day4prac.짝꿍실습;

public class 통닭천사 implements 금병영직원 {
	@Override
	public void 영상편집() {
		System.out.println("통닭천사 유튜브를 편집한다");
	}
	@Override
	public void 유튜브출연() {
		System.out.println("이상형월드컵을 한다");
	}
}
