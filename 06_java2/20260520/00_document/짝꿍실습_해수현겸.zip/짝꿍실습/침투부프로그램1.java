package day4prac.짝꿍실습;

public class 침투부프로그램1 {
	// 얘가 없으면 되지가 않는다
	// 필수
	김쥐똥고추 emp = new 김쥐똥고추();
	
	public void run() {
		System.out.println("직원 일을 시켜볼게요");
		emp.영상편집();
		
	}

	public static void main(String[] args) {

		침투부프로그램1 p = new 침투부프로그램1();
		p.run();

	}

}
