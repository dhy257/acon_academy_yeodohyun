package day4prac.짝꿍실습;

public class 침투부프로그램2 {
	
	금병영직원 emp;
	
	public 침투부프로그램2() {
		
	}
	
	public 침투부프로그램2(금병영직원 emp) {
		super();
		this.emp = emp;
	}



	public void run() {
		System.out.println("직원 일을 시킬게요");
		emp.유튜브출연();
	}

	public static void main(String[] args) {

		침투부프로그램2 p1 = new 침투부프로그램2(new 통닭천사());
		침투부프로그램2 p2 = new 침투부프로그램2(new 김쥐똥고추());
		
		p1.run();
		p2.run();

	}

}
