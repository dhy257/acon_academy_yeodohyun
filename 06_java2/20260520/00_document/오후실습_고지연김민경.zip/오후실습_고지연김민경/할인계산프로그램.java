package day4prac.오후실습.고지연김민경;

import java.util.Scanner;

public class 할인계산프로그램 {
	
	Discount discount;
	
	

	public 할인계산프로그램(Discount discount) {
		super();
		this.discount = discount;
	}


	 public void run() {
	        Scanner sc = new Scanner(System.in);

	        System.out.println("상품 금액 입력:");
	        int price = sc.nextInt();

	        int result = discount.discount(price);

	        System.out.println("할인 적용 후 금액: " + result);
	    }
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		할인계산프로그램 p = new 할인계산프로그램(new Type2할인계산기());
        p.run();
        

	}

}
