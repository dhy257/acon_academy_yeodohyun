package day4prac.오후실습.고지연김민경;

public interface Discount {
	int discount(int price);
}
