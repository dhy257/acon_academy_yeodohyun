package day4prac.오후실습.고지연김민경;

public class Type1할인계산기 implements Discount {

	@Override
	public int discount(int price) {
		// TODO Auto-generated method stub
		System.out.println("학생 할인");
		return price - (price * 10 / 100);
	}

}
