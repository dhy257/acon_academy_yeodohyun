package day4prac.오후실습.고지연김민경;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Properties;
import java.util.Scanner;


public class 할인계산프로그램2 {
	
	Discount discount;


	 public void setDiscount(Discount discount) {
		this.discount = discount;
	}

	 public void run() {
	        Scanner sc = new Scanner(System.in);

	        System.out.println("상품 금액 입력:");
	        int price = sc.nextInt();

	        int result = discount.discount(price);

	        System.out.println("할인 적용 후 금액: " + result);
	    }
	 
	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
		// TODO Auto-generated method stub
		
		Properties pp = new Properties();
		pp.load(new FileReader("src/오후실습/고지연김민경/config.txt"));
		String className = pp.getProperty("discount"); // 키를 입력 -- class정보를 반환
		
		Class clazz = Class.forName(className); //클래스에 대한 변수 만들기
		Discount discount = (Discount) clazz.getDeclaredConstructor().newInstance(); //객체반환에 대한 변수 만들기
		
		할인계산프로그램2 p = new 할인계산프로그램2();
		p.setDiscount(discount);
		p.run();
		

	}

}
