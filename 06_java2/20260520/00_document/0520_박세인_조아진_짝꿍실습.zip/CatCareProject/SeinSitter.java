package day4prac.CatCareProject;

public class SeinSitter implements CatSitter{

	@Override
	public void feedCat() {
		System.out.println("세인 집사 : 고양이에게 참치맛 츄르를 줍니다.");
		
	}

	@Override
	public void playWithCat() {
		System.out.println("세인 집사 : 레이저 포인터로 고양이와 놀아줍니다.");
		
	}

	@Override
	public void cleanLitterBox() {
		System.out.println("세인 집사 : 화장실 모래를 갈아줍니다.");
		
	}

	

}
