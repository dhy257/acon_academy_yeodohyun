package day4prac.CatCareProject;

import java.io.FileReader;
import java.io.Reader;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		
		try {
            // 1. 외부 파일 읽기
            Properties prop = new Properties();
            prop.load(new FileReader("src/day4prac/CatCareProject/config.txt"));

            String sitterClassName = prop.getProperty("sitter");

            // 2. reflection으로 클래스 정보 가져오기
            Class<?> clazz = Class.forName(sitterClassName);

            // 3. reflection으로 객체 생성
            Object obj = clazz.getDeclaredConstructor().newInstance();

            // 4. CatSitter 타입으로 변환
            CatSitter sitter = (CatSitter) obj;

            // 5. reflection으로 클래스 정보 출력
            System.out.println("===== Reflection으로 클래스 정보 확인 =====");
            System.out.println("클래스 이름: " + clazz.getName());

            Method[] methods = clazz.getDeclaredMethods();

            System.out.println("메서드 목록:");
            for (Method method : methods) {
                System.out.println("- " + method.getName());
            }

            // 6. reflection으로 메서드 직접 호출해보기
            System.out.println();
            System.out.println("===== Reflection으로 메서드 호출 테스트 =====");
            Method feedMethod = clazz.getDeclaredMethod("feedCat");
            feedMethod.invoke(obj);

            // 7. 실제 프로그램 실행
            CatHome catHome = new CatHome(sitter);

            boolean run = true;

            while (run) {
                System.out.println();
                System.out.println("===== 고양이 키우기 프로그램 =====");
                System.out.println("1. 주문하기");
                System.out.println("2. 메뉴 보여주기");
                System.out.println("3. 집사 객체를 이용하여 고양이 돌보기");
                System.out.println("4. 돌봄 결과 출력하기");
                System.out.println("0. 종료");
                System.out.print("선택 >> ");

                int choice = sc.nextInt();

                if (choice == 1) {
                    System.out.println();
                    System.out.println("고양이 돌봄을 주문했습니다.");
                    System.out.println("오늘의 집사가 배정되었습니다: " + sitterClassName);

                } else if (choice == 2) {
                    catHome.showMenu();

                } else if (choice == 3) {
                    catHome.showMenu();
                    System.out.print("돌봄 메뉴 선택 >> ");
                    int menuNo = sc.nextInt();

                    catHome.careCat(menuNo);

                } else if (choice == 4) {
                    catHome.printCareResult();

                } else if (choice == 0) {
                    System.out.println("프로그램을 종료합니다.");
                    run = false;

                } else {
                    System.out.println("잘못된 번호입니다.");
                } //
            }

        } catch (Exception e) {
            System.out.println("프로그램 실행 중 오류가 발생했습니다.");
            e.printStackTrace();
        }

        sc.close();

	}

}
