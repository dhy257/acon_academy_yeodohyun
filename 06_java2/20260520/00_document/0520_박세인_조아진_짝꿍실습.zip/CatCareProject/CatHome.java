package day4prac.CatCareProject;

public class CatHome {

	private CatSitter catSitter;
	private String lastCareResult;
	
	public CatHome(CatSitter catSitter) {
		this.catSitter = catSitter;
		this.lastCareResult = "아직 돌봄을 하지 않았습니다.";
	}
	
	public void showMenu() {
		System.out.println();
		System.out.println("===== 고양이 돌봄 메뉴 =====");
        System.out.println("1. 밥 주기");
        System.out.println("2. 놀아주기");
        System.out.println("3. 화장실 청소하기");
        System.out.println("==========================");
	}
	
	public void careCat(int menuNo) {
        System.out.println();

        if (menuNo == 1) {
            catSitter.feedCat();
            lastCareResult = "고양이가 배부르게 밥을 먹었습니다.";
        } else if (menuNo == 2) {
            catSitter.playWithCat();
            lastCareResult = "고양이가 신나게 놀았습니다.";
        } else if (menuNo == 3) {
            catSitter.cleanLitterBox();
            lastCareResult = "고양이 화장실이 깨끗해졌습니다.";
        } else {
            System.out.println("없는 메뉴입니다.");
            lastCareResult = "잘못된 메뉴를 선택했습니다.";
        }
    }
	
	public void printCareResult() {
        System.out.println();
        System.out.println("[돌봄 결과]");
        System.out.println(lastCareResult);
    }
	
	
	
	

}
