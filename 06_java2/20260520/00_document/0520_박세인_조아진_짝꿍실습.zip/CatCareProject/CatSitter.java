package day4prac.CatCareProject;

public interface CatSitter {
	
	void feedCat();
	
	void playWithCat();
	
	void cleanLitterBox();

}
