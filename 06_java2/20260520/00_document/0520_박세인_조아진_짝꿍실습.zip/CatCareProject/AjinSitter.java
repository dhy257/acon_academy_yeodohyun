package day4prac.CatCareProject;

public class AjinSitter implements CatSitter{
	
	@Override
	public void feedCat() {
		// TODO Auto-generated method stub
		System.out.println("아진 집사: 고양이에게 참치맛 사료를 줍니다.");
	}
	
	@Override
	public void playWithCat() {
		// TODO Auto-generated method stub
		System.out.println("아진 집사: 낚싯대 장난감으로 고양이와 놀아줍니다.");
		
	}
	
	@Override
	public void cleanLitterBox() {
		// TODO Auto-generated method stub
		System.out.println("아진 집사: 모래 화장실을 깨끗하게 청소합니다.");
		
	}

}
