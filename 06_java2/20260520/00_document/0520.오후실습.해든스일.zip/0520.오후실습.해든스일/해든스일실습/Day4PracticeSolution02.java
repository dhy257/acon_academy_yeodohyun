package day4prac.오후실습.해든스일실습;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Day4PracticeSolution02 {
	public static void main(String[] args) throws Exception {
		reflectionPractice();
	}
	
	private static void reflectionPractice() throws Exception {
		// 1. Class.forName()으로 CafeMenu 클래스 정보 가져오기
		Class<?> clazz = Class.forName("day4prac.오후실습.해든스일실습.CafeMenu");
		
		// 2. 필드 목록 출력
		Field[] fields = clazz.getDeclaredFields();
		for ( Field field : fields ) {
			System.out.println
			(field.getName() );
		}
		
		System.out.println();
		
		// 3. 메서드 목록 출력
		Method[] methods = clazz.getDeclaredMethods();
		for ( Method method : methods ) {
			System.out.println(
			method.getName());
		}
		
		// 4. 생성자로 객체 만들기
		Constructor<?> constructor = clazz.getDeclaredConstructor(String.class, int.class);
		Object menu = constructor.newInstance("아메리카노", 4500);

		// 5. printMenu() 호출
		Method printMenu = clazz.getDeclaredMethod("printMenu");
		printMenu.invoke(menu);

		// 6. isExpensive() 호출해서 결과 출력
		Method isExpensive = clazz.getDeclaredMethod("isExpensive");
		Object result = isExpensive.invoke(menu);
		System.out.println("비싼 메뉴인가? " + result);
		
	}

}


class CafeMenu {

	private String menuName;
	private int price;
	
	public CafeMenu(String menuName, int price) {
//		super();
		this.menuName = menuName;
		this.price = price;
	}
	
	public void printMenu() { // 메뉴명, 가격 출력
		System.out.println("메뉴명 : " + menuName);
		System.out.println("가격 : " + price);
	} 
	
	public boolean isExpensive() {   // 5000원 이상이면 true
		return price >=5000;
				
	}	
	
}

