package day4prac.오후실습_건희민정;

public class Burger implements Food {

	String[] bMenu = { "불고기버거", "새우버거", "치즈버거" };

	@Override
	public void recommend() {

		int random = (int) (Math.random() * bMenu.length);
		System.out.println("오늘의 버거 추천! : " + bMenu[random]);
	}

}
