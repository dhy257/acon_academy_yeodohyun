package day4prac.오후실습_건희민정;

public class Chicken implements Food{
	
	String[] cMenu = {
			"양념치킨",
            "후라이드치킨",
            "간장치킨",
            "마늘치킨"
	};

	@Override
	public void recommend() {
		
		int random = (int)(Math.random()*cMenu.length);
		System.out.println("오늘의 치킨 추천! : " + cMenu[random]);

	}

}
