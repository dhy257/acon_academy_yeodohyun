package day4prac.오후실습_건희민정;

public class Pizza implements Food {

	String[] pMenu = {
			
				"고구마피자",
	            "포테이토피자",
	            "불고기피자",
	            "치즈피자"
	};

	@Override
	public void recommend() {
		
		int random = (int)(Math.random()*pMenu.length);
		System.out.println("오늘의 피자 추천! : " + pMenu[random]);

	}

}
