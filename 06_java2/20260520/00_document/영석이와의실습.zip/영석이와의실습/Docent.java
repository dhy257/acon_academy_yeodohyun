package 영석이와의실습;

public interface Docent {
	void question();
	void introduce();
}
