package Javaprj.day08.팀정보;

public class team2 {

	public static void main(String[] args) {
		Team hh = new Team();
		
		input(hh);
		
		print(hh);
	}
	
	public static void input(Team hh) {
		hh.name ="한화이글스";
		hh.area="대전광역시";
		hh.direc = "김경문";
		hh.color = "주황색";
		hh.leader = "채은성";
	}
	
	public static void print(Team hh) {
		System.out.println("팀: " + hh.name);
		System.out.println("연고지: " + hh.area);
		System.out.println("감독: "+ hh.direc);		
		System.out.println("주장: "+ hh.leader);		
		System.out.println("상징색: "+ hh.color);
	}
}
