package Javaprj.day08.팀정보;

public class Team {
	String name;
	String area;
	String direc;
	String color;
	String leader;
}
