package javaprj.day08.구조화된데이터;

public class Exercise {
	
	String name;
	String place;
	String time;
	int calories;
	String price;

}
