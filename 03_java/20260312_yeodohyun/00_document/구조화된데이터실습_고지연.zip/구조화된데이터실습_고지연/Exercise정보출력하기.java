package javaprj.day08.구조화된데이터;

public class Exercise정보출력하기 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//변수만들기
		Exercise workout = new Exercise();
		
		//값넣기
		/*
		workout.name="running";
		workout.place="everywhere";
		workout.time="1 hour";
		workout.calories=750;
		workout.price="free";
		*/
		input(workout);
		
		//값출력하기
		/*
		System.out.println(workout.name);
		System.out.println(workout.place);
		System.out.println(workout.time);
		System.out.println(workout.calories);
		System.out.println(workout.price);
		*/
		print(workout);

	}
	
	public static void input(Exercise workout) {
		workout.name="running";
		workout.place="everywhere";
		workout.time="1 hour";
		workout.calories=750;
		workout.price="free";
	}
	
	public static void print(Exercise workout) {
		System.out.println("종류:  "+workout.name);
		System.out.println("장소:  "+workout.place);
		System.out.println("소요시간:"+workout.time);
		System.out.println("소모열량(kcal):"+workout.calories);
		System.out.println("비용:  "+workout.price);
		
	}

}
