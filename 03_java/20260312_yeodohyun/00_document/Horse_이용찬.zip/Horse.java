package javaprj.day08.구조화된데이터;

public class Horse {
	static String name;
	static int age;
	static int speed;
	
	public static void introduce() {
		System.out.println("내 이름은"+name);
	}
	
	public static void race() {
		System.out.println("다른 말과 경주합니다");
		int otherHorseSpeed = (int) (Math.random() * 100);
		System.out.println("다른말 speed: "+otherHorseSpeed);
		System.out.println(name+"speed: "+speed);
		
		if(speed>otherHorseSpeed) {
			System.out.println("승리했습니다");
		}else if(speed<otherHorseSpeed) {
			System.out.println("패배했습니다");
		}else {
			System.out.println("무승부");
		}
	}
}
