package javaprj.day08.구조화된데이터;

public class horse_출력 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Horse horse = new Horse();
		
		init(horse, "말똥이", 10, 50);
		
		horse.introduce();
		
		horse.race();
		
	}
	
	public static void init(Horse horse, String name, int age, int speed) {
		horse.name = name;
		horse.age = age;
		horse.speed = speed;
	}
	

}
