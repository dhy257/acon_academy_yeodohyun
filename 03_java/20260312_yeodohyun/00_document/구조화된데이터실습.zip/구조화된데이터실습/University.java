package 구조화된데이터실습;

public class University {
    //이름, 학과, 학번, 총 이수 학점, 전체학기 평균 학점,
    String name;
    String major;
    int number;
    int credit;
    float grade;
}
