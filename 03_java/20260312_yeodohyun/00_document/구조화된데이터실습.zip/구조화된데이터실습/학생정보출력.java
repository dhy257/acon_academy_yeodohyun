package 구조화된데이터실습;

import java.util.Scanner;

public class 학생정보출력 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        University university = new University();
        int trem = 0;
        int temp = 0;
        float score = 0;
        float sum = 0;
        float ave = 0;


        System.out.print("이름: ");
        university.name = sc.nextLine();

        System.out.print("학과: ");
        university.major = sc.nextLine();

        System.out.print("학번: ");
        university.number = sc.nextInt();
        sc.nextLine();

        System.out.print("이수 학기(1~8 ex. 3학년 1학기 => 5): ");
        trem = sc.nextInt();
        sc.nextLine();

        for (int i = 1 ; i <= trem ; i++) {
            System.out.print(i + "학기 이수 학점: ");
            university.credit = sc.nextInt();
            temp += university.credit;
            System.out.print(i + "학기 학점: ");
            score = sc.nextFloat();
            sum += score;
        }
        university.credit = temp;
        ave = sum / trem;
        university.grade = ave;

        System.out.println(" =======학생 정보 출력=======");
        System.out.println("이름: " + university.name);
        System.out.println("학과: " + university.major);
        System.out.println("학번: " + university.number);
        System.out.println("취득 학점: " + university.credit);
        System.out.println("평점 평균: " + university.grade);

    }
}
