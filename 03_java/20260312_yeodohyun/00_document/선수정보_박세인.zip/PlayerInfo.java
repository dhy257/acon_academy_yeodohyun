package javaprj.day08.구조화된데이터;

public class PlayerInfo {
	
	String name;
	String company;
	int age;
	int num;
	
}
