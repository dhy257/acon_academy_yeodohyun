package javaprj.day08.구조화된데이터;

public class 예제만들기_박세인 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		PlayerInfo player = new PlayerInfo();
		/*
		player.name="류현진";
		player.company="한화";
		player.age=38;
		player.num=99;
		*/
		input(player);
		
		System.out.println("<한화선수 정보>");
		/*
		System.out.println(player.name);
		System.out.println(player.company);
		System.out.println(player.age);
		System.out.println(player.num);
		*/
		print(player);
	}
	public static void input(PlayerInfo player) {
		player.name="류현진";
		player.company="한화";
		player.age=38;
		player.num=99;
	}
	
	public static void print(PlayerInfo player) {
		System.out.println("이름 : " + player.name);
		System.out.println("소속팀 : "+player.company);
		System.out.println("나이 : "+player.age);
		System.out.println("등번호 : "+player.num);
	}
}
