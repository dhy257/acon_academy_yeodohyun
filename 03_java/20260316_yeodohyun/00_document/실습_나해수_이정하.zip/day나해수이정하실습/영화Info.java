package javaprj_day09.day나해수이정하실습;

import java.util.Scanner;

public class 영화Info {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/**/
		Scanner sc = new Scanner(System.in);
		
		영화예매 m = new 영화예매();
		
		int menu = 0;
		
		loop:while(true) {
			System.out.println("1.영화예매 2.좌석조회 3.종료");
			menu = sc.nextInt();
			sc.nextLine();
			
			switch(menu) {
			case 1:
				System.out.println("영화 선택 : 왕과 사는 남자 / 호퍼스 / 삼악도");
				
				
				String movieName = sc.nextLine();
				//m.영화이름(movieName);
				
				System.out.println("좌석 번호 입력 (1~10)");
				String seatNum = sc.nextLine();
				m.좌석예매(movieName, seatNum);
				
				break;
			case 2:
				m.좌석조회();
				System.out.println("좌석 번호 입력");
				
				break;
			case 3:
				System.out.println("종료합니다");
				break loop;
		}
		
		
		영화예매 예매 = new  영화예매();
		
		예매.좌석예매("왕과사는 남자", "00");
		예매.좌석조회();
		
		
	}
		
	}
}
