package javaprj_day09.day나해수이정하실습;

import java.util.Scanner;

public class Movie {
    //영화관 좌석예매
    String movieName;
    boolean[][] seat;

    public void movie(String movieName) {
        this.movieName = movieName;
        this.seat = new boolean[2][5];
    }

    public void seatoutput() {
        for (int i = 0 ; i < seat.length ; i++) {
            for (int j = 0 ; j < seat[i].length ; j++){
                if (seat[i][j]) {
                    System.out.print(" [ X ] ");
                } else {
                    System.out.print(" [   ] ");
                }
            }
            System.out.println();
        }
    }

    public void seatNumTrue(int x, int y) {
        if (seat[x][y]) {
            System.out.println("이미 예약된 좌석입니다.");
        } else {
            seat[x][y] = true;
            System.out.println("예매 완료되었습니다.");
        }
    }

    public void seatchoice(Scanner sc) {
        System.out.println("원하는 좌석을 선택해주세요.");
        seatoutput(); //좌석 출력

        System.out.println("행을 선택해주세요. (1, 2)");
        int x = sc.nextInt();
        sc.nextLine();

        System.out.println("선택한 행에서 원하는 좌석을 선택해주세요. (1 ~ 5)");
        int y = sc.nextInt();
        sc.nextLine();
        seatNumTrue(x-1, y-1);
    }
}
