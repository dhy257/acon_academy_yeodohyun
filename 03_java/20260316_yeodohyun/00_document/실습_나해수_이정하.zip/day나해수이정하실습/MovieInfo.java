package javaprj_day09.day나해수이정하실습;

import java.util.Scanner;

public class MovieInfo {
    public static void main(String[] args) {

        Movie movie1 = new Movie();
        Movie movie2 = new Movie();
        Movie movie3 = new Movie();

        movie1.movie("왕과사는남자");
        movie2.movie("호퍼스");
        movie3.movie("삼악도");

        Scanner sc = new Scanner(System.in);


        Movie choiceMovie = movie1;
        int menu = 0;

        loop:while(true) {
            System.out.println("현재 상영중인 영화: 왕과사는 남자, 호퍼스, 삼악도");
            System.out.println("1. 영화 선택     2. 선택한 영화 좌석 조회      3. 종료");
            menu = sc.nextInt();
            sc .nextLine();
            switch (menu) {
                case 1:
                    System.out.println("영화를 선택해주세요.");
                    System.out.println("1. 왕과 사는 남자     2. 호퍼스     3. 삼악도");
                    int num = sc.nextInt();
                    sc.nextLine();
                    if (num == 1) {
                        choiceMovie = movie1;
                    } else if (num == 2) {
                        choiceMovie = movie2;
                    } else if (num == 3) {
                        choiceMovie = movie3;
                    } else {
                        System.out.println("1, 2, 3번 중에서만 선택해주세요.");
                        break;
                    }
                    //예매
                    choiceMovie.seatchoice(sc);
                    break;
                case 2:
                    System.out.println("++ 선택한 영화 좌석 정보 ++");
                    choiceMovie.seatoutput();
                    break;
                case 3:
                    System.out.println("종료합니다.");
                    break loop;
            }
        }
    }
}

