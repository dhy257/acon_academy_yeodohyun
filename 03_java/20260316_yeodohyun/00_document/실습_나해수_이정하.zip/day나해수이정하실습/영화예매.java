package javaprj_day09.day나해수이정하실습;

public class 영화예매 {

 
	//영화티켓  티켓;
	String  영화이름;
	String  좌석번호;
	boolean[][] seat = new boolean[2][5]; 
	 
	 
	//
	public void 좌석예매(String name,  String seatNum) {   // "00"   => true
		
		this.영화이름 = name;
		this.좌석번호 = seatNum;
		
		
		//행
		int row  = seatNum.charAt(0) -48 ;   // '0   :48' ->0    //0
		//열
		int col  = seatNum.charAt(1) -48 ;  // '0' -> 0		
		
		seat[row][col]=true;
		
		System.out.println("예약 완료");
		
		//영화티켓 티켓  = new 영화티켓();
		//티켓.입력(name, seatNum);
		
		
	}
	
	// 티켓출력하기
	public void 티켓출력() {
		System.out.println("영화 : " + 영화이름);
		System.out.println("좌석 : " + 좌석번호);
	}
	
	
	public void 좌석조회() {
		for(int i=0; i<seat.length; i++) {
			for(int j=0; j<seat[i].length; j++) {
				if( seat[i][j]==true) {
					System.out.print(" X ");
				}else {
					System.out.print(" O ");
				}
			}
			
			System.out.println();
		}
		
	}

	
	/*
	//입력
	public void 입력( String  영화이름, String 좌석번호) {
			 
		this.영화이름 =영화이름;
		this.좌석번호 = 좌석번호;
	}
		 
	//출력
		 
	public void   출력() {
		System.out.println(영화이름 +  좌석번호);
	}
	*/	 
	
	
	

}

	
