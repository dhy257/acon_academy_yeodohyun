package team;

public class BookInfo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Book b1 = new Book();
		Book b2 = new Book();
		Book b3 = new Book();
		
		b1.book_info("모던 자바스크립트 Deep Dive", "위키북스", "이웅모", false, 100);
		b2.book_info("모순", "살림", "양귀자", true, 200);
		b3.book_info("물고기는 존재하지 않는다", "곰출판판", "룰루 밀러", false, 300);
		
		b2.returndate = "206-03-01";
		
		//책 정보 출력
		b1.book_print();
		b2.book_print();
		b3.book_print();
		
		
		b1.rental(100);
//		b1.book_print();
//		
//		b1.rental(100);
		
		
	}

}
