package team;

import java.time.LocalDate; 
import java.time.format.DateTimeFormatter;

public class Book {
	String rentaldate;	
	String returndate;

	boolean isRental;	//true -> 대여중	false -> 대여가능
	
	String name;
	String publisher;
	String author;
	int isbn;	//도서코드

	public void rental(int isbn) {
		
		if(this.isRental==true) {	
			System.out.println("이미 다른 사람이 대여중인 책입니다.");
		}else {
			
			System.out.println("대여가 가능합니다.\n");
			
			this.isRental = true;
			
			LocalDate rentalDate = LocalDate.now();
			LocalDate returnDate = rentalDate.plusDays(7);
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy년 MM월 dd일");
			
	        this.rentaldate = rentalDate.format(formatter);
	        this.returndate = returnDate.format(formatter);
			
			System.out.println("빌린 날짜는 " + this.rentaldate + "\n");
			System.out.println("반납 날짜는 " + this.returndate);	
			System.out.println("================================");
		}	
	}
	
	
	public void book_info(String name, String publisher, String author, boolean isRental, int isbn) {	//책 정보 저장
		this.name = name;
		this.publisher = publisher;
		this.author = author;
		this.isRental = isRental;
		this.isbn = isbn;
	}
	
	public void book_print() {	//책 정보 출력
		System.out.println("책제목 : " + this.name);
		System.out.println("출판사 : " + this.publisher);
		System.out.println("저자 : " + this.author);
		
		if(this.isRental == true) {
			System.out.println("대여 가능 여부 : 불가능");
		}else {
			System.out.println("대여 가능 여부 : 가능");
		}
		
		System.out.println("도서코드 : " + this.isbn);
		System.out.println("================================");
	}
	
	
	
	
}
