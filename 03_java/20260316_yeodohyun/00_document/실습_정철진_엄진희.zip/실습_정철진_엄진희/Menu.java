package test;

import java.util.Scanner;

public class Menu {
	
	/*
	 * 음식주문 프로그램
	 * 
	 * 짜장면 = 100
	 * 짬뽕 = 100
	 * 탕수육 = 100
	 * 
	 * 주문 => (입력한 만큼 빼기)
	 * 음식만들기 => +5
	 * */
	
	int 짜장면 = 100;
	int 짬뽕 = 100;
	int 탕수육 = 100;
	
	public void 주문(int 짜장면, int 짬뽕, int 탕수육) {
		this.짜장면 -= 짜장면;
		this.짬뽕 -= 짬뽕;
		this.탕수육 -= 탕수육;
	}
	
	public void 음식만들기() {
	    this.짜장면 += 5;
	    this.짬뽕 += 5;
	    this.탕수육 += 5;
	}
	
	public void 재고관리() {
		System.out.println("짜장면: "+this.짜장면);
		System.out.println("짬뽕: "+this.짬뽕);
		System.out.println("탕수육: "+this.탕수육);
	}
	
	public static void main(String[] args) {
		Menu menu = new Menu();
		
		Scanner sc = new Scanner(System.in);
		int food1 = sc.nextInt();
		int food2 = sc.nextInt();
		int food3 = sc.nextInt();
		
		menu.재고관리();
		
		System.out.println();
		
		menu.주문(food1, food2, food3);
		menu.재고관리();
		
		menu.음식만들기();
		menu.재고관리();
	}
}
