package test;

import java.util.Scanner;

public class Menu2 {
	
	/*
	 * 음식주문 프로그램
	 * 
	 * 짜장면 = 100
	 * 짬뽕 = 100
	 * 탕수육 = 100
	 * 
	 * 주문 => (입력한 만큼 빼기)
	 * 음식만들기 => +5
	 * */
	
	int 짜장면 = 100;
	int 짬뽕 = 100;
	int 탕수육 = 100;
	Scanner sc = new Scanner(System.in);
	
	public void 주문(int 짜장면, int 짬뽕, int 탕수육) {
		this.짜장면 -= 짜장면;
		this.짬뽕 -= 짬뽕;
		this.탕수육 -= 탕수육;
	}
	
	public void 음식만들기() {
	    this.짜장면 += 5;
	    this.짬뽕 += 5;
	    this.탕수육 += 5;
	}
	
	public void 재고관리() {
		System.out.println("짜장면: "+this.짜장면);
		System.out.println("짬뽕: "+this.짬뽕);
		System.out.println("탕수육: "+this.탕수육);
	}
	
	public void 메뉴선택() {
		while (true) {
			System.out.println("메뉴선택 1.주문 | 2.음식만들기 | 3.재고확인");
			int select = sc.nextInt();
			
			if(select == 5) {
				break;
			}
			
			switch (select) {
			case 1: {
				주문(5,5,5);
				재고관리();
				break;
			}
			case 2: {
				음식만들기();
				재고관리();
				break;
			}
			case 3: {
				재고관리();
				break;
			}
			default:
				System.out.println("잘못입력");
			}
		}
	}
	
	public static void main(String[] args) {
		Menu2 menu = new Menu2();
		menu.메뉴선택();
	}
}
