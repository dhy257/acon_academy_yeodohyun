package test;

public class 계산기2 {
	public void a (int a, int b) {
		System.out.println( (a+b) );
	}
	
	public void b (int a, int b) {
		System.out.println( (a-b) );
	}
	
	public void c (int a, int b) {
		System.out.println( (a*b) );
	}
	
	public void d (int a, int b) {
		System.out.println( (a/b) );
	}
}