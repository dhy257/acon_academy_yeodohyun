package test;

import java.util.Scanner;

public class 계산기출력2 {
	
	public static void main(String[] args) {
		계산기 cal = new 계산기();
		
		Scanner sc = new Scanner(System.in);
		
		
		System.out.println("숫자입력");
		int num1 = sc.nextInt();
		int num2 = sc.nextInt();
		
		cal.a(num1, num2);
		cal.b(num1, num2);
		cal.c(num1, num2);
		cal.d(num1, num2);
	}

}