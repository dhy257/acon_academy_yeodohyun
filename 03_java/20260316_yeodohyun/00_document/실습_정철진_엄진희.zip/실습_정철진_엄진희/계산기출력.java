package test;

public class 계산기출력 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		계산기 cal = new 계산기();
		
		cal.a( 10,5);
		cal.b( 10,5);
		cal.c( 10,5);
		cal.d( 10,5);
		
	}

}