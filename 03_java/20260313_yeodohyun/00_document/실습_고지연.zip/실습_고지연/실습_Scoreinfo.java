package javaprj.day09;

public class 실습_Scoreinfo {

	public static void main(String[] args) {
		
		
		//변수선언
		실습_Score no1=new 실습_Score();
		
		//호출
		no1.input("홍길동", 90, 80, 0);//avg에는 초기화값 넣기
		no1.print();

	}

}
