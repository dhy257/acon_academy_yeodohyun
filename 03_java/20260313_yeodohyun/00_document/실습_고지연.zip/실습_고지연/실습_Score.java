package javaprj.day09;

public class 실습_Score {
	
	//구조화된 데이터
	private String name;
	private int kor;
	private int eng;
	private int avg;
	
	//입력
	public void input(String name, int kor, int eng, int avg) {
		this.name=name;
		this.kor=kor;
		this.eng=eng;
		this.avg=((this.kor+this.eng)/2);
		
	}
	
	//출력
	public void print() {
		System.out.println("학생이름:  "+this.name);
		System.out.println("국어성적:  "+this.kor);
		System.out.println("영어성적:  "+this.eng);
		System.out.println("평균점수:  "+this.avg);
	}

}
