package javaprj.day09;

public class 실습_Shopping {
	/*
	주문번호: 201803120001
	주문자아이디: abc123
	주문날짜:2018년3월12일
	주문자이름: 홍길순
	주문상품번호😛D0345-12
	배송주소: 서울시 영등포구 여의도동 20번지
	*/
	
	//구조화된 데이터 만들기
	//입력하기
	//출력하기
	
	private long number;
	private String id;
	private String date;
	private String name;
	private String productnumber;
	private String address;
	
	//입력하기 
	public void input(long number, String id, String date, String name, String productnumber, String address) {
		this.number=number;
		this.id=id;
		this.date=date;
		this.name=name;
		this.productnumber=productnumber;
		this.address=address;
	}
	
	//출력하기
	public void print() {
		System.out.println("주문번호:"+this.number);
		System.out.println("아이디:  "+this.id);
		System.out.println("날짜:   " +this.date);
		System.out.println("이름:   "+this.name);
		System.out.println("상품번호:"+this.productnumber);
		System.out.println("주소:   "+this.address);

		
	}
	
	

}
