package javaprj.day09;

public class Exercise2 {
	
	private String name;
	private String place;
	private String time;
	private int calories;
	private String price;


//입력하기
public void input (String name, String place, String time, int calories, String price) {
	this.name=name;
	this.place=place;
	this.time=time;
	this.calories=calories;
	this.price=price;
}
//출력하기
public void print() {
	System.out.println("종류:  "+this.name);
	System.out.println("장소:  "+this.place);
	System.out.println("소요시간:"+this.time);
	System.out.println("소모열량(kcal):"+this.calories);
	System.out.println("비용:  "+this.price);
	
}




}
