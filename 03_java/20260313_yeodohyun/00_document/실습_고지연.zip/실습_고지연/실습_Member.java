package javaprj.day09;

public class 실습_Member {
	
	
	//데이터입력
	
	String name;
	int age;
	boolean isMarried;
	int children;
	
	//입력하기
	
	public void input(String name, int age, boolean isMarried, int children) {
		this.name=name;
		this.age=age;
		this.isMarried=isMarried;
		this.children=children;
	}
	
	//출력하기
	public void print() {
		System.out.println("이름:  "+this.name);
		System.out.println("나이:  "+this.age);
		System.out.println("결혼:  "+this.isMarried);
		System.out.println("자녀수: "+this.children);
	}
	
	
	/*
	1. 사람의 정보를 담을 클래스 만들기

	 나이가 40살, 이름이 james 라는 남자가 있습니다.
	 이 남자는 결혼을 했고  자식이 셋 있습니다.

	출력결과
	이 사람이 나이
	이 사람의 이름
	이 사람의 결혼 여부
	이사람의 자녀수

	(각 멤버변수에 맞는 자료형을 생각해 보세요: 결혼여부 isMarried => boolean)
	*/
	

}
