package javaprj.day09;


public class Exercise정보출력하기2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//변수만들기
		Exercise2 movement = new Exercise2();
		Exercise2 movement2 = new Exercise2();
		
		movement.input("running", "everywhere", "1hour", 750, "free"); //movement.로 객체의 정보가 전달되어서 괄호안 참조형 변수 삭제가능
		movement.print();
		
		movement2.input("swimming","pool","1hour",600,"cheap");
		movement2.print();

	}
	//입력하기
	/*
	
	}
	*/
	//출력하기
	
	

}
