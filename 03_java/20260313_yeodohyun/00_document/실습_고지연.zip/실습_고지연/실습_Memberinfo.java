package javaprj.day09;

public class 실습_Memberinfo {

	public static void main(String[] args) {
		
		//변수만들기
		실습_Member no1=new 실습_Member();
		실습_Member no2=new 실습_Member();
		
		//호출하기
			
		no1.input("James", 40, true, 3);
		no1.print();
		no2.input("Heyho", 20, false, 0);
		no2.print();	
		

	}

}
