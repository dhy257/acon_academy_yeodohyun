package javaprj.day09;

public class 실습_Shoppinginfo {

	public static void main(String[] args) {
		
		
		//변수만들기
		
		실습_Shopping item1=new 실습_Shopping();
		
		//호출하기
		//long은 뒤에 l을 붙여서 사용
		item1.input(201803120001l, "abc123", "2018년3월12일", "홍길순", "D0345-12", "서울시 영등포구 여의도동 20번지");
		item1.print();		

	}

}
