package javaprj.day09_객체;

public class shoppingInfo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		shopping shopping = new shopping();
		shopping.input(201803120001l, "abc123", "2018년3월12일", "홍길순", "D0345-12", "서울시 영등포구 여의도동 20번지");
		shopping.output();
	}

}
