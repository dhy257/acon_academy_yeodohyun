package javaprj.day09_객체;

public class shopping {
	private long num;
	private String id;
	private String date;
	private String name;
	private String productNum;
	private String address;
	
	public void input(long num, String id, String date, String name, String productNum, String address) {
		this.num = num;
		this.id = id;
		this.date = date;
		this.name = name;
		this.productNum = productNum;
		this.address = address;
	}
	
	public void output() {
		System.out.println(this.num);
		System.out.println(this.id);
		System.out.println(this.date);
		System.out.println(this.name);
		System.out.println(this.productNum);
		System.out.println(this.address);
	}
}
