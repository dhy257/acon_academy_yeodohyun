package javaprj.day09_객체;

public class horse {
	String name;
	int age;
	int speed;
	
	public void input(String name, int age, int speed) {
		this.name = name;
		this.age = age;
		this.speed = speed;
	}
	
	public void introduce() {
		System.out.println("내 이름은 "+this.name);
	}
	
	public void race() {
		System.out.println("다른 말과 경주합니다");
		int otherHorseSpeed = (int) (Math.random() * 100);
		System.out.println("다른말 speed: "+otherHorseSpeed);
		System.out.println(name+"speed: "+this.speed);
		
		if(this.speed>otherHorseSpeed) {
			System.out.println("승리했습니다");
		}else if(this.speed<otherHorseSpeed) {
			System.out.println("패배했습니다");
		}else {
			System.out.println("무승부");
		}
	}
}
