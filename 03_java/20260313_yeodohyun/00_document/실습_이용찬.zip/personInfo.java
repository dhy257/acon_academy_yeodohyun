package javaprj.day09_객체;

public class personInfo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		person person = new person();
		person.input(40, "james", true, 3);
		person.output();
	}

}
