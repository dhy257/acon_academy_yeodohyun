package javaprj.day09_객체;

public class horseInfo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		horse horse = new horse();
		horse.input("말똥이", 10, 50);
		horse.introduce();
		horse.race();
	}

}
