package javaprj.day09_객체;

public class person {
	private int age;
	private String name;
	private boolean married;
	private int child;
	
	public void input(int age, String name, boolean married, int child) {
		this.age = age;
		this.name = name;
		this.married = married;
		this.child = child;
	}
	
	public void output() {
		System.out.println(this.age);
		System.out.println(this.name);
		System.out.println(this.married);
		System.out.println(child);
	}
}
