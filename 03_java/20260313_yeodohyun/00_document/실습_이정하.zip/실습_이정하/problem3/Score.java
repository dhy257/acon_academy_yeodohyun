package 실습_이정하.problem3;

public class Score {
    String name;
    int kor;
    int eng;
    int avg;
}
