package javaprj.day09;

public class Person {
	int age;
	String name;
	boolean isMarried;
	int baby;
	
	public void input(int age, String name, boolean isMarried, int baby) {
		this.age = age;
		this.name = name;
		this.isMarried = isMarried;
		this.baby = baby;
	}
	
	public void print() {
		System.out.println("나이 : " + this.age);
		System.out.println("이름 : " + this.name);
		
		if(this.isMarried == true) {
			System.out.println("결혼여부 : " + "기혼");
		}else {
			System.out.println("결혼여부 : " + "미혼");
		}
		
		System.out.println("자녀수 : " + this.baby);
	}
}
