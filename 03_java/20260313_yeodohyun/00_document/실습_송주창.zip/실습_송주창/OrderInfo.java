package javaprj.day09;

public class OrderInfo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Order od = new Order();
		
		od.input("201803120001", "abc123", "2018년3월12일", "홍길순", "D0345-12", "영등포구 여의도동 20번지");
		od.print();
	}

}
