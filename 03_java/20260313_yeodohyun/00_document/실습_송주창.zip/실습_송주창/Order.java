package javaprj.day09;

public class Order {
	String order_num, id, order, name, address,product_num, order_date ;

	
	public void input(String order_num, String id, String order_date, String name, String product_num, String address) {
		this.order_num = order_num;
		this.id = id;
		this.order_date = order_date;
		
		this.name = name;
		this.product_num = product_num;
		this.address = address;
	}
	
	public void print() {
		System.out.println("주문번호 : " + this.order_num);
		System.out.println("주문자 아이디 : " + this.id);
		System.out.println("주문날짜 : " + this.order_date);
		
		System.out.println("주문자 이름 : " + this.name);
		System.out.println("주문상품번호 : " + this.product_num);
		System.out.println("배송주소 : " + this.address);
	}
}
