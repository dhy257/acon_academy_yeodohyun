package javaprj.day09;

import java.util.Scanner;

public class Personinfo {

	public static void main(String[] args) {
		
		Person p = new Person();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("나이를 입력하세요.");
		p.age = sc.nextInt();
		
		System.out.println("이름을 입력하세요.");
		p.name = sc.next();
		
		System.out.println("결혼여부을 입력하세요.(true, false)");
		p.isMarried = sc.nextBoolean();
		
		System.out.println("자녀수를 입력하세요.");
		p.baby = sc.nextInt();
			
		p.input(p.age, p.name, p.isMarried, p.baby);
		
		//p.input(40, "James", true, 3);
		p.print();
	}

}
