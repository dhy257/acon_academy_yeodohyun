package javaprj.day09;

public class Score {
	/*
	 * 3. 학생성적을 담을  class  작성하기
		 Score 이름으로 작성하시오
		   - name 학생이름
		   - kor  국어성적
		   - eng 영어성적
		   - avg 평균   
		
		
		   출력결과
		     학생이름: 홍길동
		     국어 :90
		     영어 :80
		     평균: 85
	 * */
	String name;
	int kor;
	int eng;
	int avg;
	
	
	public Score(String name, int kor, int eng) {
		this.name = name;
		this.kor = kor;
		this.eng = eng;
		this.avg = (kor + eng) / 2;
	}
	
	public void showInfo() {
		System.out.println("학생이름: " + this.name);
		System.out.println("국어 :" + this.kor);
		System.out.println("영어 :" + this.eng);
		System.out.println("평균: " + this.avg);
	}
	
	public static void main(String[] args) {
			Score student = new Score("홍길동", 90, 80);
			student.showInfo();
			
	}
}
