package javaprj.day09;

public class Order {
	/*
	 * 주문번호: 201803120001
			주문자아이디: abc123
			주문날짜:2018년3월12일
			주문자이름: 홍길순
			주문상품번호😛D0345-12
			배송주소: 서울시 영등포구 여의도동 20번지*/
	
	String orderNum;
	String id;
	String date;
	String name;
	String prodNum;
	String addr;
	
	public Order(String orderNum, String id, String date, String name, String prodNum, String addr) {
		this.orderNum = orderNum;
		this.id = id;
		this.date = date;
		this.name = name;
		this.prodNum = prodNum;
		this.addr = addr;
	}
	
	public void showInfo() {
		System.out.println("주문번호: "+orderNum);
		System.out.println("주문자아이디: "+id);
		System.out.println("주문날짜: "+date);
		System.out.println("주문자이름: "+name);
		System.out.println("주문상품번호: "+prodNum);
		System.out.println("배송주소: "+addr);
		
	}
	
	public void setInfo(String orderNum, String id, String date, String name, String prodNum, String addr) {
		this.orderNum = orderNum;
		this.id = id;
		this.date = date;
		this.name = name;
		this.prodNum = prodNum;
		this.addr = addr;
	}
	
	public static void main(String[] args) {
		Order order = new Order(null, null, null, null, null, null);
		
		System.out.println("생성자 최초 초기화\n");
		order.showInfo();
		
		System.out.println();
		System.out.println("값 변경 후\n");
		
		order.setInfo("201803120001", "abc123", "2018년3월12일", "홍길순", "D0345-12", "서울시 영등포구 여의도동 20번지");
		order.showInfo();
	}
}
