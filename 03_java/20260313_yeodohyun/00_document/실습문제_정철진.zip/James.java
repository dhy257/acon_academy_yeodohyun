package javaprj.day09;

public class James {
	int age;
	String name;
	boolean marriage;
	int child;
	
	public James(int age, String name, boolean marriage, int child) {
        this.age = age;
        this.name = name;
        this.marriage = marriage;
        this.child = child;
    }
	
	public void showInfo() {
		System.out.println("이름: " + name);
        System.out.println("나이: " + age);
        System.out.println("결혼 여부: " + (marriage ? "기혼" : "미혼"));
        System.out.println("자녀 수: " + child);
	}
	
	public static void main(String[] args) {
		James james = new James(40, "james",true,3);
		
		james.showInfo();
	}
}
