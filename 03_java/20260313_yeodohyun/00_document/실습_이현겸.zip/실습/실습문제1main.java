package javaprj.day09.실습;

public class 실습문제1main {

	public static void main(String[] args) {
		
		// 객체 선언
		실습문제1 james = new 실습문제1();
		
		// 입력
		james.입력하기(40, "james", true, 3);
		
		// 출력
		james.출력하기();

	}

}
