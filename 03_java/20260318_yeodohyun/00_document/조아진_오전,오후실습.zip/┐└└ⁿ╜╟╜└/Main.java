package javaprj.day12.오전실습;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Zelda zelda = new Zelda();
		Lol lol = new Lol();
		System.out.println("==========🟡01번 문제==========");
		System.out.println("✨객체 생성✨");
		
		Game g1 = zelda;
		Game g2 = lol;
		System.out.println("\n==========🟡03번 문제==========");
		System.out.println("✨업캐스팅 해 보기✨");
		
		g1.게임을한다(); // Zelda
		g2.게임을한다(); // Lol
		System.out.println("\n==========🟡04번 문제==========");
		System.out.println("✨부모형 참조시 자식의 모든 내용 안보임✨");
		
		if(g1 instanceof Zelda) {
			System.out.println("\n==========🟡05번 문제==========");
			System.out.println("✨instanceof 확인✨");
			
			//
			
			Zelda zelda2 = (Zelda) g1;
			
			//
			System.out.println("\n==========🟡06번 문제==========");
			System.out.println("✨다운캐스팅 후 자식 고유기능 사용(Zelda)✨");
			System.out.println("\n-자식 고유 기능 : ");
			zelda2.젤다를구한다();
			zelda2.칼을휘두른다();
			
			System.out.println("\n-부모 기능도 사용 가능");
			zelda2.게임을한다();
			
			
		}
		
		if(g2 instanceof Lol) {
			
			//
			Lol lol2 = (Lol) g2;
			//
			System.out.println("✨다운캐스팅 후 자식 고유기능 사용(Zelda)✨");
			System.out.println("\n-자식 고유 기능 : ");
			lol2.협곡으로();
			lol2.적처치();
			lol2.게임을한다();
			
		}

	}

}
