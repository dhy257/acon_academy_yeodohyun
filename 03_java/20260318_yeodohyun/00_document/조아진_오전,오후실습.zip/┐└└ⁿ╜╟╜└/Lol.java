package javaprj.day12.오전실습;

public class Lol extends Game {
	public void 협곡으로() {
		System.out.println("협곡에 오신 걸 환영합니다");
	}
	
	public void 적처치() {
		System.out.println("적을 처치했습니다");
	}

}
