package javaprj.day12.오전실습;

public class Game {
	
	
	public void 게임을한다() {
		System.out.println("🎮게임을 한다🎮");
	}
}
