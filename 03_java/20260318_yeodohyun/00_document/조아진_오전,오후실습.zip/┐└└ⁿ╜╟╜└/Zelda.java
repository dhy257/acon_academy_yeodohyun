package javaprj.day12.오전실습;

public class Zelda extends Game {
	
	public void 젤다를구한다() {
		System.out.println("젤다를 구한다");
	}
	
	public void 칼을휘두른다() {
		System.out.println("라이넬을 처치하였습니다.");
	}

}
