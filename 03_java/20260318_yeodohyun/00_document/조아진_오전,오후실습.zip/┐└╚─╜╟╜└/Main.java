package javaprj.day12.오후실습;

public class Main {
	
	// 🟡 매서드 만들고 매개변수의 다형성 사용
	public static void 오니처치(DemonSlayer ds) { // 매개변수로 DemonSlayer 부모 타입을 받으면 모두 이 매서드 사용 가능
		System.out.println("악귀멸살");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println();
		
		// 🟡 DS 타입 배열 만들고, 캐릭터 객체 넣기(자식 객체가 부모 타입으로 자동 변환되어 들어가는 거 => 업캐스팅)
		
		System.out.println("=========상속관계 클래스 여러개 & 여러 자식 부모형 객체 배열 다루기=========");
		DemonSlayer[] slayer = new DemonSlayer[4];
		slayer[0] = new DemonSlayer(); // 부모 객체			
		slayer[1] = new Giyu(); 
		System.out.println("=========업캐스팅 부분 : 기유 부분부터=========");
		// 업캐스팅 부분(자식 객체가 부모 타입으로 자동 변환되어 들어감)
		// 기유는 귀살대원이다 => 자동 형변환 = 업캐스팅		
		slayer[2] = new Tanjiro();
		slayer[3] = new Zenitsu();
		
		for(int i=0; i<slayer.length; i++) { // 객체배열 반목문으로 각 객체에 매서드 호출
			slayer[i].호흡사용();
		}
		
		System.out.println(); // 띄우고
		
		for(int i=0; i<slayer.length; i++) {
			
			
			if( slayer[i] instanceof Giyu ) { // 배열에 있는 진짜 알맹이가 기유 타입이 맞는지 확인
				System.out.println("=========다운캐스팅 부분=========");
				Giyu gy = (Giyu) slayer[i]; // (Giyu) => 다운캐스팅(강제 형변환)
				gy.호흡사용(); // 부모 기능도 사용 가능
				System.out.print("기유 : ");				
				gy.물의호흡();
				// 다운캐스팅 이유 : 업캐스팅해서 부모 형태로 있을 때는 자식만의 고유한 기술 사용불가
				// 자식의 고유 매서드인 물의호흡()을 호출하려면 이게 필요하다
			}
			
			System.out.println();
			
			if( slayer[i] instanceof Tanjiro ) {
				Tanjiro tj = (Tanjiro) slayer[i];
				tj.호흡사용();
				System.out.print("탄지로 : ");
				tj.해의호흡();
			}
			
			System.out.println();
			
			if( slayer[i] instanceof Zenitsu ) {
				Zenitsu zt = (Zenitsu) slayer[i];
				zt.호흡사용();
				System.out.print("젠이츠 : ");
				zt.번개의호흡();
			}
		}
		
		System.out.println("\n=========잘못된 다운캐스팅 예제=========");
		
		DemonSlayer slayer2 = new DemonSlayer(); // 부모 객체 생성
		
		Tanjiro tj2 = (Tanjiro) slayer2; // slayer2는 순수 부모 객체인데 (Tanjiro) => 억지로 탄지로 타입으로 변환(다운캐스팅) 시도
		// => 에러
		// slayer2에는 탄지로 고유 기능(해의 호흡)을 가질 수 있는 메모리 공간 자체가 없다
		// 부모 객체는 자식 객체로 억지로 모습을 바꿀 수 없다. 애초에 자식이 아니기 때문
	}

}
