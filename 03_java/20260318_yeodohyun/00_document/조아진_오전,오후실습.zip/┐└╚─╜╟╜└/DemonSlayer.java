package javaprj.day12.오후실습;

public class DemonSlayer {
	public void 호흡사용() {
		System.out.println("🗡️ 호흡을 사용합니다 🗡️");
	}
}
