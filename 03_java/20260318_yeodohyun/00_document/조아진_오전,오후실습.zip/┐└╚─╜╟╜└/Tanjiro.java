package javaprj.day12.오후실습;

public class Tanjiro extends DemonSlayer{
	
	@Override
	public void 호흡사용() { // 부모 매서드 재정의(오버라이드)
		System.out.println("🗡️ 전집중 호흡 히노카미카구라 🗡️");
	}
	
	public void 해의호흡() {
		System.out.println("🌞 히노카미카구라 제 6형 작골염양 🌞");
	}

}
