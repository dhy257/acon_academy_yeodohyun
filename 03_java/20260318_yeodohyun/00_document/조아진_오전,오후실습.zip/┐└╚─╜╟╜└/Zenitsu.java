package javaprj.day12.오후실습;

public class Zenitsu extends DemonSlayer{
	
	@Override
	public void 호흡사용() {
		
		System.out.println("🗡️ 전집중 호흡 번개의 호흡 🗡️");
	}
	
	public void 번개의호흡() {
		System.out.println("⚡ 번개의 호흡 제 7형 화뢰신 ⚡");
	}
}
