package javaprj.day12.오후실습;

public class Giyu extends DemonSlayer{
	
	@Override
	public void 호흡사용() {
		System.out.println("🗡️ 전집중 호흡 물의 호흡 🗡️");
	}
	
	public void 물의호흡() {
		System.out.println("💦 물의 호흡 제 11형 잔잔한 물결 💦");
	}
}
