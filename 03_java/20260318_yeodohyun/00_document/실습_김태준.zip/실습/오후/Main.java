package pro0318.실습.오후;

public class Main {
	
	public static void main(String[] args) {
		
		Enemy boss = new Enemy("거대 보스",5000);
		
		Operator[] arr = new Operator[6]; 
		
		arr[0] = new Guard("가드", "남", 28, 6, "물리", "근거리/원거리", 2, 715);
		arr[1] = new Caster("캐스터", "여", 16, 6, "마법", "원거리", 1, 645);
		arr[2] = new Medic("메딕", "여", 26, 6, "마법", "원거리", 1, 510);
		arr[3] = new Sniper("스나이퍼", "여", 20, 6, "물리", "원거리", 1, 540);
		arr[4] = new Specialist("스페셜리스트", "남", 27, 6, "물리", "근거리", 1, 580);
		arr[5] = new Vanguard("뱅가드", "여", 22, 5, "물리", "근거리", 2, 470);
		
		
		for(int i=0;i< arr.length;i++) {
			arr[i].hello();
			System.out.println();
			arr[i].스킬사용();
			arr[i].행동하기(boss);
			System.out.println();
			if(arr[i] instanceof Guard) {
				((Guard)arr[i]).특징();
			}else if(arr[i] instanceof Caster) {
				((Caster)arr[i]).특징();
			}else if(arr[i] instanceof Medic) {
				((Medic)arr[i]).특징();
			}else if(arr[i] instanceof Sniper) {
				((Sniper)arr[i]).특징();
			}else if(arr[i] instanceof Specialist) {
				((Specialist)arr[i]).특징();
			}else if(arr[i] instanceof Vanguard) {
				((Vanguard)arr[i]).특징();
			}
			System.out.println();
		}
	}
}
