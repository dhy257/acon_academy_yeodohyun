package pro0318.실습.오후;

public class Vanguard extends Operator{
	String 직군이름;
	
	public Vanguard(String name, String 성별, int age, int star, String 데미지유형, String 사거리유형, int 저지수, int 기본공격력) {
		super(name, 성별, age, star, 데미지유형, 사거리유형, 저지수, 기본공격력);
		직군이름 = "뱅가드";
	}
	
	@Override
	public void 스킬사용() {
		System.out.println("데미지*1.1");
		기본공격력 *= 1.1;
	}
	
	public void 특징() {
		System.out.println(직군이름+"는 코스트를 회복할 수 있습니다.");
	}
}
