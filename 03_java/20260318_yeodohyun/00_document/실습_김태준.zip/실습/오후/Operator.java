package pro0318.실습.오후;

public class Operator {
	String name;
	String 성별;
	int age;
	int star;
	String 데미지유형;
	String 사거리유형;
	int 저지수;
	int 기본공격력;
	
	
	public Operator(String name,String 성별,int age,int star,String 데미지유형,String 사거리유형,int 저지수,int 기본공격력) {
		this.name = name;
		this.성별 = 성별;
		this.age = age;
		this.star = star;
		this.데미지유형 = 데미지유형;
		this.사거리유형 = 사거리유형;
		this.저지수 = 저지수;
		this.기본공격력 = 기본공격력;
	}
	
	public void hello() {
		System.out.println("오퍼레이터 정보:");
		System.out.println("이름:"+name);
		System.out.println("성별:"+성별);
		System.out.println("나이:"+age);
		System.out.println("레어도:"+star);
		System.out.println("사거리유형:"+데미지유형);
		System.out.println("데미지유형:"+사거리유형);
		System.out.println("저지수:"+저지수);
		System.out.println("기본공격력:"+기본공격력);
	}
	
	public void 행동하기(Enemy target) {
		System.out.println(this.name + "이(가) " + target.name + "을(를) 공격합니다.");
		target.takeDamage(this.기본공격력,this.데미지유형);
	}
	
	public void 스킬사용() {
		System.out.println("캐릭터가 스킬을 사용합니다.");
	}
}
