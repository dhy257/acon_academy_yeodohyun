package pro0318.실습.오후;

public class Enemy {
	
	int hp;
	String name;
	int 물리_방어도;
	int 마법_방어도;
	
	public Enemy(String 이름,int 피) {
		hp = 피;
		name = 이름;
		물리_방어도 = 500;
		마법_방어도 = 30;
	}
	
	public void takeDamage(int damage, String 데미지유형) {
		int finalDamage = damage; // 최종 데미지를 담을 변수
		
		if (데미지유형.equals("물리")) {
			finalDamage -= 물리_방어도;
			// 방어도가 공격력보다 높을 경우 최소 데미지를 5% 정도로 보장하는 기믹 (실제 게임 시스템 참조)
			if (finalDamage < (damage * 0.05)) {
				finalDamage = (int)(damage * 0.05); 
			}
		} else if (데미지유형.equals("마법")) {
			// 마법 방어도 20 = 20% 감소 = 원래 데미지의 80%만 적용
			// 연산: damage * (100 - 20) / 100.0
			finalDamage = (int)(damage * (100 - 마법_방어도) / 100.0);
		}
		
		if (finalDamage < 0) finalDamage = 0; // 최종 데미지가 음수가 되는 것을 원천 차단
		
		this.hp -= finalDamage;
		if (this.hp < 0) this.hp = 0; 
		
		System.out.println(this.name + "이(가) [" + 데미지유형 + "] 공격으로 " + finalDamage + "의 피해를 입었습니다. (남은 HP: " + this.hp + ")");
	}
}
