package pro0318.실습.오후;

public class Guard extends Operator{
	String 직군이름;

	public Guard(String name, String 성별, int age, int star, String 데미지유형, String 사거리유형, int 저지수, int 기본공격력) {
		super(name, 성별, age, star, 데미지유형, 사거리유형, 저지수, 기본공격력);
		직군이름 = "가드";
	}
	
	
	@Override
	public void 스킬사용() {
		System.out.println("저지수*2,데미지유형 변경");
		저지수*=2;
		데미지유형="마법";
	}
	
	public void 특징() {
		System.out.println(직군이름+"는 육각형으로 우수한 능력치로 적과 대치합니다.");
	}
}
