package pro0318.실습.오후;

public class Sniper extends Operator{
	String 직군이름;

	public Sniper(String name, String 성별, int age, int star, String 데미지유형, String 사거리유형, int 저지수, int 기본공격력) {
		super(name, 성별, age, star, 데미지유형, 사거리유형, 저지수, 기본공격력);
		직군이름 = "스나이퍼";
	}

	
	
	@Override
	public void 스킬사용() {
		System.out.println("공격력이 증가합니다");
		기본공격력*=1.3;
	}
	
	public void 특징() {
		System.out.println(직군이름+"는 빠른 공격속도와 사거리로 적을 공격합니다.");
	}
}
