package pro0318.실습.오후;

public class Medic extends Operator{
	String 직군이름;

	public Medic(String name, String 성별, int age, int star, String 데미지유형, String 사거리유형, int 저지수, int 기본공격력) {
		super(name, 성별, age, star, 데미지유형, 사거리유형, 저지수, 기본공격력);
		직군이름 = "메딕";
	}
	
	@Override
	public void 행동하기(Enemy target) {
		System.out.println("메딕은 적을 공격할 수 없습니다.(남은 HP: " + target.hp + ")");
	}
	
	@Override
	public void 스킬사용() {
		System.out.println(직군이름+ "은 사거리가 증가합니다.공격력이 상승합니다.");
		기본공격력*=2;
		사거리유형 = "좀 더 긴 원거리";
	}
	
	public void 특징() {
		System.out.println(직군이름+"은 아군의 hp를 회복시킬 수 있습니다.");
	}
	
}
