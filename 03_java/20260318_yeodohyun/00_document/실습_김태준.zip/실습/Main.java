package pro0318.실습;

public class Main {
	
	public static void main(String[] args) {
		
		동아시아 japan = new 일본();
		동아시아 korea = new 한국();
		동아시아 china = new 중국();
		
		동아시아[] asia = new 동아시아[] {korea,japan,china};
		
		매서드(asia);
	}
	
	public static void 매서드(동아시아[] asia) {
		for(int i=0; i<asia.length;i++) {
			
			System.out.print("나의 나라의 수도는 ");
			asia[i].수도말하기();
			
			if(asia[i] instanceof 한국) {
				((한국)asia[i]).온돌();
			}else if(asia[i] instanceof 일본) {
				((일본)asia[i]).다도();
			}else if(asia[i] instanceof 중국) {
				((중국)asia[i]).경극();
			}
			
		}
	}
}
