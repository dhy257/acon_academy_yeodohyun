package pro0318.실습;

public class 한국 extends 동아시아{
	
	public void 온돌() {
		System.out.println("온돌은 한국의 가장 독창적인 주거 문화이자 과학적인 난방 시스템입니다.");
	}
	
	@Override
	public void 수도말하기() {
		// TODO Auto-generated method stub
		System.out.println("서울");
	}
}
