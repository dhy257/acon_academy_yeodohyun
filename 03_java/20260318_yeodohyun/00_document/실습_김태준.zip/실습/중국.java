package pro0318.실습;

public class 중국 extends 동아시아{
	
	public void 경극() {
		System.out.println("경극은 중국의 역사, 문학, 예술이 집약된 종합 공연 예술입니다.");
	}
	
	@Override
	public void 수도말하기() {
		// TODO Auto-generated method stub
		System.out.println("베이징");
	}
}
