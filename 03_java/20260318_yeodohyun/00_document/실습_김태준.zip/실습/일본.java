package pro0318.실습;

public class 일본 extends 동아시아{
		
	public void 다도() {
		System.out.println("다도는 차를 마시는 행위를 엄격한 절차와 예법을 갖춘 예술의 경지로 승화시킨 문화입니다..");
	}
	
	@Override
	public void 수도말하기() {
		// TODO Auto-generated method stub
		System.out.println("도쿄");
	}
}
