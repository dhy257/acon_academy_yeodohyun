package pro0318.실습;

public class 동아시아 {

	public void 수도말하기() {
		System.out.println("우리에겐 모두 수도가 있어");
	}
}
